// ✅ Stocke le postId courant pour savoir où ajouter le commentaire
let currentPostId = null;

// ✅ Fonction appelée quand on clique sur le bouton "💬 Commentaires"
function openCommentDrawer(postId) {
  console.log("Post ID sélectionné :", postId); // Debug
  currentPostId = postId;

  fetchAndDisplayComments(postId); // Charge les commentaires du post

  // Ouvre le drawer (basculer classe Tailwind)
  const drawer = document.getElementById('commentDrawer');
  drawer.classList.remove('translate-y-full');
}

// ✅ Gestion de l’envoi du formulaire de commentaire
document.getElementById('commentForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const token = localStorage.getItem('token');
  if (!token) {
    alert("Tu dois être connecté pour commenter.");
    return;
  }

  if (!currentPostId) {
    alert("Aucun post sélectionné.");
    return;
  }

  const commentContent = document.getElementById('commentContent').value.trim();
  console.log("Contenu du commentaire saisi :", commentContent); // Debug

  if (!commentContent) {
    alert("Le commentaire est vide.");
    return;
  }

  try {
    const res = await fetch(`http://localhost:3000/api/comments/post/${currentPostId}/add`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify({ content: commentContent })
    });

    if (!res.ok) throw new Error('Erreur lors de l’envoi du commentaire');

    const newComment = await res.json();
    appendCommentToDOM(newComment); // Ajoute dans la liste
    document.getElementById('commentContent').value = ''; // Réinitialise champ

  } catch (err) {
    console.error(err);
    alert("Erreur d'ajout de commentaire.");
  }
});

// ✅ Récupère et affiche les commentaires d’un post donné
async function fetchAndDisplayComments(postId) {
  try {
    const res = await fetch(`http://localhost:3000/api/comments/post/${postId}`);
    if (!res.ok) throw new Error('Erreur de récupération des commentaires');

    const comments = await res.json();
    const container = document.getElementById('commentsContainer');
    container.innerHTML = '';

    comments.forEach(appendCommentToDOM);
  } catch (err) {
    console.error(err);
    alert("Impossible de charger les commentaires.");
  }
}

// ✅ Ajoute un commentaire dans le DOM (en haut de la liste)
function appendCommentToDOM(comment) {
  const container = document.getElementById('commentsContainer');

  const commentDiv = document.createElement('div');
  commentDiv.className = 'bg-gray-100 p-2 rounded mb-2';

  commentDiv.innerHTML = `
    <strong>@${comment.username}</strong>
    <p>${comment.content}</p>
    <small class="text-xs text-gray-500">${new Date(comment.created_at).toLocaleString()}</small>
  `;

  container.prepend(commentDiv);
}
