document.addEventListener('DOMContentLoaded', fetchAndDisplayPosts);

async function fetchAndDisplayPosts() {
  try {
    const response = await fetch('http://localhost:3000/api/posts');
    if (!response.ok) throw new Error('Failed to fetch posts');

    const posts = await response.json();
    const postList = document.getElementById('postList');
    postList.innerHTML = '';

    posts.reverse().forEach(post => {
      const postCard = document.createElement('div');
      postCard.className = 'post-card';

      postCard.innerHTML = `
        <div class="post-header">
          <div class="user-info">
            <img src="https://i.pravatar.cc/100?u=${post.user_id}" alt="Profile" class="profile-pic" />
            <div class="username-time">
              <strong>@${post.username}</strong>
              <small>${new Date(post.created_at).toLocaleString()}</small>
            </div>
          </div>
          <div class="more-options">⋮</div>
        </div>

        <img src="http://localhost:3000/uploads/${post.image_url}" alt="Post Image" class="post-image" />
        <p class="caption">${post.caption}</p>

        <div class="post-actions">
          <span>❤️ 152</span>
          <button class="openCommentBtn" data-post-id="${post.id}">💬 Commentaires</button>
        </div>
      `;

      postList.appendChild(postCard);
    });

    // ✅ Important : attacher les écouteurs après le rendu
    

  } catch (error) {
    console.error('Error fetching posts:', error);
    const postList = document.getElementById('postList');
    postList.innerHTML = '<p>Failed to load posts.</p>';
  }
}

// ✅ Fonction appelée après avoir injecté les posts dans le DOM
function attachCommentListeners() {
  const commentButtons = document.querySelectorAll('.openCommentBtn');

  commentButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const postId = btn.dataset.postId;
      openCommentDrawer(postId); // ← Appelle la fonction de add-comment.js
    });
  });
}
attachCommentListeners();
